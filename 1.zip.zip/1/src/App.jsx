import React, { useState } from 'react';
import Header from './components/Header'
import Progress from './components/Progress';
import FirstStep from './components/FirstStep';
import SecondStep from './components/SecondStep';
import Result from './components/Result';
import ThirdStep from './components/ThirdStep';

const App = () => {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({});

  const handleNext = (newData) => {
    setData({ ...data, ...newData });
    setStep(step + 1);
  };
  console.log(data);

  const handlePrev = () => {
    setStep(step - 1);
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return <FirstStep handleNext={handleNext} />;
      case 2:
        return <SecondStep handleNext={handleNext} handlePrev ={handlePrev}/>;
      case 3:
        return <ThirdStep handleNext={handleNext}  handlePrev ={handlePrev}/>;
      case 4:
        return <Result data={data} />;
      default:
        return <FirstStep handleNext={handleNext} />;
    }
  };

  return (
    <div className="App">
      <Header />
      <Progress step={step} />
      {renderStep()}
    </div>
  );
};

export default App;