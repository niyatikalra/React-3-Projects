import React from 'react';
import styles from './css/Header.module.css'

const Header = () => (
  <div className={styles.header}>
    <h1 className={styles.headerH1}>Multi Step Registration</h1>
  </div>
);

export default Header;