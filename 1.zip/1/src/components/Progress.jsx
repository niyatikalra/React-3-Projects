import React from 'react';
import styles from './css/Progress.module.css';

const Progress = ({ step }) => (
  <div className={styles.steps}>
    <div className={`${styles.step} ${step >= 1 ? styles.completed : ''}`}>
      <div>1</div>
      <div>Step 1</div>
    </div>
    <div className={`${styles.step} ${step >= 2 ? styles.completed : ''}`}>
      <div>2</div>
      <div>Step 2</div>
    </div>
    <div className={`${styles.step} ${step >= 3 ? styles.completed : ''}`}>
      <div>3</div>
      <div>Step 3</div>
    </div>
  </div>
);

export default Progress;