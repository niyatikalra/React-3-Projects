import React from 'react';

const CustomInput = React.forwardRef((props, ref) => {
  return (
    <input {...props} ref={ref} className={`${props.className ? props.className : ''}`} />
  );
});

export default CustomInput;