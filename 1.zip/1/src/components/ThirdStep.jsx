import React from 'react';
import { useForm } from 'react-hook-form';
import { Form, Button } from 'react-bootstrap';

const ThirdStep = ({ handleNext }) => {
  const { register, handleSubmit, errors } = useForm({
    defaultValues: {
      phone: '',
      address: '',
    },
  });

  const onSubmit = (data) => {
    handleNext(data);
  };

  return (
    <Form className="input-form" onSubmit={handleSubmit(onSubmit)}>
      <Form.Group controlId="phone">
        <Form.Label>Phone</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter your phone number"
          autoComplete="off"
          {...register('phone', {
            required: 'Phone number is required',
          })}
          className={`${errors?.phone ? 'input-error' : ''}`}
        />
        {errors?.phone && (
          <p className="errorMsg">{errors.phone.message}</p>
        )}
      </Form.Group>

      <Form.Group controlId="address">
        <Form.Label>Address</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter your address"
          autoComplete="off"
          {...register('address', {
            required: 'Address is required',
          })}
          className={`${errors?.address ? 'input-error' : ''}`}
        />
        {errors?.address && (
          <p className="errorMsg">{errors.address.message}</p>
        )}
      </Form.Group>

      <Button variant="primary" type="submit">
        Next
      </Button>
    </Form>
  );
};

export default ThirdStep;