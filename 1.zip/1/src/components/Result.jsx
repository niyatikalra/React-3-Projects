import React from 'react';
import './css/Result.css';

const Result = (props) => {
  return (
    <div className="result-container">
      <h2 className="result-header">Registration Successful!</h2>
      <div className="result-item">
        <span className="result-label">Name:</span>
        <span className="result-value">{props.data.firstName} {props.data.lastName}</span>
      </div>
      <div className="result-item">
        <span className="result-label">Email:</span>
        <span className="result-value">{props.data.email}</span>
      </div>
      <div className="result-item">
        <span className="result-label">Password:</span>
        <span className="result-value">{props.data.password}</span>
      </div>
      <div className="result-item">
        <span className="result-label">Phone:</span>
        <span className="result-value">{props.data.phone}</span>
      </div>
      <div className="result-item">
        <span className="result-label">Address:</span>
        <span className="result-value">{props.data.address}</span>
      </div>
    </div>
  );
};

export default Result;
