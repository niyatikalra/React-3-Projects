import React from "react";
import { useForm } from "react-hook-form";
import { Form, Button } from "react-bootstrap";

const FirstStep = (props) => {
  const { register, handleSubmit, errors, formState } = useForm({
    defaultValues: {
      firstName: "",
      lastName: "",
    },
  });

  const onSubmit = (data) => {
    console.log(data);
    props.handleNext(data);
  };

  return (
    <Form className="input-form" onSubmit={handleSubmit(onSubmit)}>
      <Form.Group controlId="firstName">
        <Form.Label>First Name</Form.Label>
        <Form.Control
          type="text"
          name="firstName"
          placeholder="Enter your first name"
          autoComplete="off"
          {...register("firstName", {
            required: "First Name is required",
            minLength: {
              value: 2,
              message: "First Name should be at least 2 characters long",
            },
          })}
          className={`input-field ${errors?.firstName ? "input-error" : ""}`}
        />
        
        {errors?.firstName && (
          <p className="errorMsg">{errors.firstName.message}</p>
        )}
      </Form.Group>

      <Form.Group controlId="lastName">
        <Form.Label>Last Name</Form.Label>
        <Form.Control 
          type="text"
          name="lastName"
          placeholder="Enter your last name"
          autoComplete="off"
          {...register("lastName", {
            required: "Last Name is required",
            minLength: {
              value: 2,
              message: "Last Name should be at least 2 characters long",
            },
          })}
          className={`${errors?.lastName ? "input-error" : ""}`}
        />
        {errors?.lastName && (
          <p className="errorMsg">{errors.lastName.message}</p>
        )}
      </Form.Group>

      <Button variant="primary" type="submit" disabled={!formState.isValid}>
        Next
      </Button>
    </Form>
  );
};

export default FirstStep;
