import React from "react";
import { useForm } from "react-hook-form";
import { Form, Button } from "react-bootstrap";

const SecondStep = (props) => {
  const { register, handleSubmit, errors } = useForm({
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = (data) => {
    console.log(data);
    props.handleNext(data);
  };

  return (
    <Form className="input-form" onSubmit={handleSubmit(onSubmit)}>
      <Form.Group controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="email"
          placeholder="Enter your email"
          autoComplete="off"
          {...register("email", {
            required: "Email is required",
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              message: "Invalid email address",
            },
          })}
          className={`${errors?.email ? "input-error" : ""}`}
        />
        {errors?.email && <p className="errorMsg">{errors.email.message}</p>}
      </Form.Group>

      <Form.Group controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type="password"
          placeholder="Enter your password"
          autoComplete="off"
          {...register("password", {
            required: "Password is required",
            minLength: {
              value: 8,
              message: "Password should be at least 8 characters long",
            },
          })}
          className={`${errors?.password ? "input-error" : ""}`}
        />
        {errors?.password && (
          <p className="errorMsg">{errors.password.message}</p>
        )}
      </Form.Group>

      <Button variant="primary" type="submit">
        Next
      </Button>
    </Form>
  );
};

export default SecondStep;
